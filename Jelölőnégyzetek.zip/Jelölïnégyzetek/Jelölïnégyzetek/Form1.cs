﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jelölőnégyzetek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //Vagy most jelölték be, vagy most vették ki a jelölést róla
            if (radioButton1.Checked)
            {
                label2.Text = "Értéke: a kiválasztott szám értéke";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //Ha a második rádiógomb lett kiválasztva
            if (radioButton2.Checked)
            {
                label2.Text = "Értéke: 10";
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                label2.Text = "Értéke: 10";
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                label2.Text = "Értéke: 10";
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
            {
                label2.Text = "Értéke: 1, vagy 11";
            }
        }
    }
}
