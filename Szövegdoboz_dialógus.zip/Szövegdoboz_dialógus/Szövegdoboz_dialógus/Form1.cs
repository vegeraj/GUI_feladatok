﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Szövegdoboz_dialógus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A szövegdoboz tartalma\nTöbb sorban", "Szövegdoboz címe", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Kilépés megerősítése dialógusablak segítségével
            DialogResult result = MessageBox.Show("Biztosan kilépsz?", "Kilépés megerősítése", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            
            switch(result)
                {
                case DialogResult.Yes:
                    Application.Exit();
                    break;
                case DialogResult.No:
                    button2.Text = "No";
                    break;
                case DialogResult.Cancel:
                    button2.Text = "Cancel";
                    break;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Jelenítsünk meg egy OpenFileDialog ablakot
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Fájl megnyitása";
            openFileDialog.Filter = "Szövegfájlok (*.txt)|*.txt|Minden fájl (*.*)|*.*";
            openFileDialog.InitialDirectory = "C:\\";
            openFileDialog.Multiselect = false;
            //Itt nyitjuk meg a dialógusablakot és ellenőrizzük az eredményt
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //Ide kerül a kiválasztott fájl elérési útja
                string filePath = openFileDialog.FileName;
                MessageBox.Show("Kiválasztott fájl: " + filePath, "Fájl kiválasztva", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //Ha nincs kiválasztott fájl
            else
            {
                MessageBox.Show("Nincs kiválasztott fájl.", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Jelenítsünk egy ColorDialog ablakot
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.AllowFullOpen = true;
            colorDialog.AnyColor = true;
            colorDialog.ShowHelp = true;
            //Itt nyitjuk meg a dialógusablakot és ellenőrizzük az eredményt
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                //Ide kerül a kiválasztott szín
                Color selectedColor = colorDialog.Color;
                this.BackColor = selectedColor; //A form háttérszínének beállítása a kiválasztott színre
            }
        }
    }
}
