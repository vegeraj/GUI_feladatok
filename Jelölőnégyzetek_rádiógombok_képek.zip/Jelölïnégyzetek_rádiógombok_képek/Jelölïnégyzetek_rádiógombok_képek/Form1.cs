﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jelölőnégyzetek_rádiógombok_képek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Az első rádiógomb csoport kezelője: fizetési mód meghatározása
        //A kezelő metódus paraméterei: object sender - a küldő objektum,
        //EventArgs e - esemény adatok, az eseményhez kapcsolódó plusz információk
        private void fizetésigombok_Kezelője(object sender, EventArgs e)
        {
            //A küldő objektum, amelyik hívja ezt a kezelőt, az egy rádiógomb, sender néven:
            label1.Text = "Választott fizetési mód: " + ((RadioButton)sender).Text;

        }

        //A második rádiógomb csoport kezelője: szállítási mód meghatározása
        private void szállításigombok_Kezelője(object sender, EventArgs e)
        {

            label2.Text = "Választott szállítási mód: " + ((RadioButton)sender).Text;

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            //A gomb engedélyezése a jelölőnégyzet állapotától függ
            button1.Enabled = checkBox2.Checked;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked) {
                MessageBox.Show("A vásárlás sikeresen megtörtént, hírlevelet küldünk!\n");
            }
            else {
                MessageBox.Show("A vásárlás sikeresen megtörtént, hírlevél nélkül!\n");
            }
        }
    }
}
