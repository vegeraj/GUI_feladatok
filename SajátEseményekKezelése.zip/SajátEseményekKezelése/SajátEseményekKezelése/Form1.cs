﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SajátEseményekKezelése
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Egy saját számláló objektum globális példányosítása,
        //mondjuk egy edényben lévő víz hőmérsékletének mérésére, kezdetben 20 fokos víz és 100 fokos küszöbérték beállításával:
        Számláló vízHőmérsékletSzámláló = new Számláló(20, 100);

        private void Form1_Load(object sender, EventArgs e)
        {
            //Eseménykezelő feliratkozás, mi történjen, ha a küszöbérték elérése esemény bekövetkezik:
            vízHőmérsékletSzámláló.KüszöbElérve += VízHőmérsékletSzámláló_KüszöbElérve;

            //Elindítjuk a hőmérséklet növelését, és kiírjuk a textBox1-be az aktuális értékeket:
            textBox1.Text += "Aktuális hőmérséklet: " + vízHőmérsékletSzámláló.AktuálisÉrték + "\r\n";
           

        }

        //Ez a metódus fogja kezelni a KüszöbElérve eseményt:
        private void VízHőmérsékletSzámláló_KüszöbElérve(object sender, EventArgs e)
        {
            //Vizsgáljuk meg, hogy a küszöbérték átlépése felfelé vagy lefelé történt-e:
            KüszöbEseményArgs küszöbEseményArgs = (KüszöbEseményArgs)e;
            string irány = küszöbEseményArgs.FelfeléÁtlépés ? "felfelé" : "lefelé";
            MessageBox.Show($"A víz hőmérséklete elérte a küszöbértéket ({irány} átlépés)!\r\n");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int növekmény = 0;
            try
            {
                növekmény = Convert.ToInt32(textBox2.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Kérem, adjon meg egy érvényes egész számot a növekményhez!");
                return;
            } 
            vízHőmérsékletSzámláló.Növel(növekmény);
            textBox1.Text += "Növeltük ennyivel: " + növekmény + "\r\n";
            textBox1.Text += "Aktuális hőmérséklet: " + vízHőmérsékletSzámláló.AktuálisÉrték + "\r\n";
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            int csökkentőÉrték = 0;
            try
            {
                csökkentőÉrték = Convert.ToInt32(textBox3.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Kérem, adjon meg egy érvényes egész számot a csökkentő értékhez!");
                return;
            } 
            vízHőmérsékletSzámláló.Csökkent(csökkentőÉrték);
            textBox1.Text += "Csökkentettük ennyivel: " + csökkentőÉrték + "\r\n";
            textBox1.Text += "Aktuális hőmérséklet: " + vízHőmérsékletSzámláló.AktuálisÉrték + "\r\n";
        }
    }
}
