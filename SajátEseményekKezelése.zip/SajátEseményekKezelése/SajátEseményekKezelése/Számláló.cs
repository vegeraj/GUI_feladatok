﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SajátEseményekKezelése
{
    //Saját Eventargs osztály készítése, ha szeretnénk átadni a küszöb átlépésének irányát is!
    //Ez egy Eventargs leszármazott osztály:
    internal class KüszöbEseményArgs : EventArgs
    {
        //Adatmező a küszöb átlépésének irányához:
        private bool felfeléÁtlépés; //true, ha felfelé léptük át a küszöböt, false, ha lefelé
        //Tulajdonság a felfeléÁtlépés lekérdezéséhez:
        public bool FelfeléÁtlépés
        {
            get { return felfeléÁtlépés; }
        }
        //Konstruktor, amely beállítja az adatmezőt:
        //Ha true, akkor felfelé léptük át a küszöböt, ha false, akkor lefelé
        public KüszöbEseményArgs(bool felfeléÁtlépés)
        {
            this.felfeléÁtlépés = felfeléÁtlépés;
        }
    }

    //Saját, számláló osztály létrehozása,amely eseményt vált ki, amikor a számláló értéke eléri a megadott küszöbértéket.
    internal class Számláló
    {
        //Adatmező:
        private int aktuálisÉrték; //A számláló aktuális értéke
        private int küszöbÉrték; //A küszöbérték, amely elérésekor eseményt váltunk ki
        //Tulajdonságok, az aktuális értékek lekérdezéséhez:
        public int AktuálisÉrték
        {
            get { return aktuálisÉrték; }
        }

        public int KüszöbÉrték
        {
            get { return küszöbÉrték; }
            set { küszöbÉrték = value; }
        }

        //Konstruktor, legyen megadható mind az aktuális érték, mind a küszöbérték:
        public Számláló(int aktuálisÉrték, int küszöbÉrték)
        {
            this.küszöbÉrték = küszöbÉrték;
            this.aktuálisÉrték = aktuálisÉrték;
        }

        //Saját esemény deklarálása, amely akkor kerül meghívásra, amikor a számláló eléri a küszöbértéket:
        //Az esemény típusa lehet saját delegált is, de itt egyszerűség kedvéért az EventHandler gyári típust használjuk:
        //Az esemény neve: KüszöbElérve
        public event EventHandler KüszöbElérve;
        //Metódus a számláló növelésére:
        public void Növel(int növekmény)
        {
            aktuálisÉrték += növekmény;
            //Ellenőrzés, hogy elértük-e a küszöbértéket.
            //Csak egyszer jelezzen, amikor épp eléri vagy meghaladja a küszöbértéket, többször nem:
            if (aktuálisÉrték >= küszöbÉrték && aktuálisÉrték - növekmény < küszöbÉrték)
            {
                //Esemény kiváltása, ha van feliratkozott eseménykezelő
                //Jelenleg csak egy üres EventArgs objektumot adunk át a kezelőnek:
                //KüszöbElérése(EventArgs.Empty);
                //Az eseménykezelőnek most már a saját KüszöbEseményArgs típusú eseményadatot adjuk át:
                KüszöbElérése(new KüszöbEseményArgs(true));
            }
        }

        //Metódus a számláló csökkentésére
        public void Csökkent(int csökkentőÉrték)
        {
            aktuálisÉrték -= csökkentőÉrték;
            //Ellenőrzés, hogy fentről lefelé átléptük-e a küszöbértéket.
            if (aktuálisÉrték <= küszöbÉrték && aktuálisÉrték + csökkentőÉrték > küszöbÉrték)
            {
                //Esemény kiváltása, ha van feliratkozott eseménykezelő
                //KüszöbElérése(EventArgs.Empty);
                //Saját KüszöbEseményArgs típusú eseményadat átadása az eseménykezelőnek:
                KüszöbElérése(new KüszöbEseményArgs(false));
            }
        }

        //Saját privát metódus készítése, az esemény kiváltására:
        private void KüszöbElérése(EventArgs e)
        {
            //Saját esemény kiváltása:
            EventHandler handler = KüszöbElérve;
            if (handler != null)
            {
                //Esemény kiváltása, paraméterek: saját objektumunk a sender, és az esemény adatai (itt üres EventArgs):
                handler(this, e);
            }
        }
    }
}
