﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Szövegdobozok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Kiírja a szövegdoboz tartalmát a label2-re
            label2.Text = "Szia, kedves " + textBox1.Text + "!";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //A textbox2be írt évszám alapján számoljuk ki az életkort és írjuk ki a label4-re
            //Konvertáljuk át a szövegdobozt számértékre
            int születésiÉv = Convert.ToInt32(textBox2.Text);
            //Határozzuk meg a jelenlegi évet a rendszeridőből 
            int jelenlegiÉv = DateTime.Now.Year;
            int életkor = jelenlegiÉv - születésiÉv;
            label4.Text = "A korod: " + életkor + " év";
        }
    }
}
