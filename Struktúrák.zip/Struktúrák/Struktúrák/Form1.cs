﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Struktúrák
{
    //Egy új, Pont struktúra definiálása:
    struct Pont
    {   //adattagok
        private int x;
        private int y;

        //getterek és setterek vannak a Java-ban, C#-ban tulajdonságok (properties) vannak
        /*public int getx()
        {
            return x;
        }
        public void setx(int x)
        {
            this.x = x;
        }
        public int gety()
        {
            return y;
        }
        public void sety(int y)
        {
            this.y = y;
        }*/

        //Tulajdonságok, properties (getterek és setterek helyett)
        //A nevük megegyezik az adattag nevével, csak nagy kezdőbetűvel írva
        public int X
        {
            get { return x; }
            set
            { //Ne engedjünk a koordinátáknak negatív értéket felvenni
                if (value < 0) x = 0;
                else x = value; 
            }
        }
        public int Y
        {
            get { return y; }
            set
            { //Ne engedjünk a koordinátáknak negatív értéket felvenni
                if (value < 0) y = 0;
                else y = value;
            }
        }

        //konstruktor
        public Pont(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        //metódus
        public string koordinatak()
        {
            return $"Pont koordinátái: ({X}, {Y})";
        }
    }

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Új pont konstrukciója, mintha egy osztálypéldányt hoznánk létre
            Pont pont = new Pont(20,40);
            //Pont koordinátáinak megváltoztatása a tulajdonságokon keresztül
            //Úgy hívjuk meg, mint egy adattagot, de valójában a set metódus fut le mögötte
            pont.X = -10;
            pont.Y = -20;
            //A lekérdezése is úgy néz ki, mintha adattag lenne:
            int helyi_x = pont.X;
            //Pont koordinátáinak kiíratása
            label1.Text = pont.koordinatak();
        }
    }
}
