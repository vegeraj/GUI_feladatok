﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Delegált típus létrehozása:
        //A delegált típus egy olyan adattípus, amely egy vagy több metódus hivatkozását tárolja.
        public delegate void Zenelejátszó(string szerző, string cím);

        //Metódusok, amelyek megfelelnek a delegált típusnak:
        public void Komolyzene(string szerző, string cím)
        {
            MessageBox.Show("Komolyzene lejátszása: " + szerző + " - " + cím);
            label1.Text = "Komolyzene lejátszása: " + szerző + " - " + cím;
        }

        public void Popzene(string szerző, string cím)
        {
            MessageBox.Show("Popzene lejátszása: " + szerző + " - " + cím);
            label1.Text = "Popzene lejátszása: " + szerző + " - " + cím;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //Delegált példányosítása és metódus hozzárendelése (feliratkozás a metódusra):
            //Zenelejátszó zenelejátszó = new Zenelejátszó(Komolyzene);
            Zenelejátszó zenelejátszó = Komolyzene; //Rövidebb szintaxis
            //A delegált meghívása (mögötte a Komolyzene metódus fog hívódni):
            zenelejátszó("Beethoven", "Für Elise");
            //A delegált hozzárendelésének megváltoztatása (átirányítás másik metódusra):
            zenelejátszó = Popzene;
            //Delegált újabb meghívása:
            zenelejátszó("Michael Jackson", "Thriller");

            //Több metódus hozzárendelése a delegálthoz (többes feliratkozás):
            //A += operátorral további metódusokat lehet hozzáadni a delegálthoz.
            zenelejátszó += Komolyzene; //Hozzáadás a delegálthoz
            zenelejátszó("Modern előadó", "Modern dal");
            //Ekkor a Popzene és a Komolyzene metódus is lefut egymás után.
            //Vagyis egyetlen delegált hívás több metódust is végrehajthat.
            //Amennyiben a delegált egy eseményt kezel, több metódust is lefuttathatunk 
            //egy esemény bekövetkezésekor.
            //Ugyanakkor több eseményre is feliratkozhat ugyanaz a metódus, ha az események
            //ugyanazzal a delegált típussal vannak definiálva.
        }


        //Ugyanannak a gombnak ugyanazon Click eseményére több metódus is feljelentkezik:
        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "button1 click metódus lefutott.";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text += " button2 click metódus lefutott.";
        }


    }
}
