﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pozicionálás
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Készítsünk egy számlálót, a gombra kattintva növekedjen az értéke!
        //A számláló globális változó lesz, így az értéke megmarad a gombkattintások között is!
        int szamlalo = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            szamlalo++;
            //Írjuk ki a számláló értékét a label_szamlalo címkére!
            label_szamlalo.Text = szamlalo.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //A számláló címkéjét mozgassuk balra egy kicsit!
            //label_szamlalo.Left -= 5;
            //A számláló címke pozícióját változtassuk meg a Location tulajdonság segítségével!
            label_szamlalo.Location = new Point(label_szamlalo.Location.X - 5, label_szamlalo.Location.Y);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //A számláló címkéjét mozgassuk jobbra egy kicsit!
            label_szamlalo.Location = new Point(label_szamlalo.Location.X + 5, label_szamlalo.Location.Y);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Zárjuk be az alkalmazást!
            Application.Exit();
        }
    }
}
